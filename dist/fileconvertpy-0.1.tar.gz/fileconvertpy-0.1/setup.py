from setuptools import setup

setup(
    name='fileconvertpy',
    version='0.1',
    packages=['fileconvert'],
    install_requires=[],
)